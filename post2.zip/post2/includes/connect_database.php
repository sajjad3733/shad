<?php 
	include($_SERVER['DOCUMENT_ROOT'].'/post2/variables/variables.php'); 
	$connect->set_charset('utf8');
?>